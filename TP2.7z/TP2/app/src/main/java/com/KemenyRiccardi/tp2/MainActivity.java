package com.KemenyRiccardi.tp2;

import android.content.Intent;
import android.graphics.Color;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import java.util.Random;
import android.content.res.Resources;


public class MainActivity extends AppCompatActivity {

    Button[] VecBtn = new Button[9];
    int idNum=0;
    Boolean vecEstados[]={Boolean.FALSE,Boolean.FALSE,Boolean.FALSE,Boolean.FALSE,Boolean.FALSE,Boolean.FALSE,Boolean.FALSE,Boolean.FALSE,Boolean.FALSE};
    String ReciboNombre;
     int[] vecJugadasActuales ;

    //BtnEnviar       = (Button) findViewById(R.id.BtnEnviar);
    @Override

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Intent elIntent = getIntent();
        Bundle datos = elIntent.getExtras();
         ReciboNombre = datos.getString (InicioActivity.NOMBRE);
        DeclaracionVariables();
        SetearListeners();

        PrenderRandom();

        CasosPosibles(idNum);
        Checkear();


    }

    private void PrenderRandom() {
        Random generadorDeNumeros = new Random();
        int numeroEsperado = generadorDeNumeros.nextInt(9 - 1) + 1;
        String strRandom="Btn".concat(Integer.toString(numeroEsperado));
        Button BtnRandom;
        Resources res=getResources();
        int id =res.getIdentifier(strRandom,"id",getApplicationContext().getPackageName());
        if(id>0){
            BtnRandom=(Button)findViewById(id);
            BtnRandom.setBackgroundColor(Color.YELLOW);
        }
    }


    private int[] CasosPosibles(int idNum) {
        switch (idNum){
            case 1:
               /*vecEstados[3]=Boolean.TRUE;
               vecEstados[5]=Boolean.TRUE;
               BtnBoton2.setBackgroundColor(Color.YELLOW);
               BtnBoton4.setBackgroundColor(Color.YELLOW);*/
                return new int[]{1,2,4};
            case 2:
                //  vecEstados[2]=Boolean.TRUE;
                //  vecEstados[4]=Boolean.TRUE;
                //  vecEstados[0]=Boolean.TRUE;
                //  BtnBoton2.setBackgroundColor(Color.BLUE);
                //  BtnBoton1.setBackgroundColor(Color.YELLOW);
                //  BtnBoton3.setBackgroundColor(Color.YELLOW);
                //  BtnBoton5.setBackgroundColor(Color.YELLOW);
                return new int[]{2,1,3,5};
            case 3:
                //vecEstados[1]=Boolean.TRUE;
                //vecEstados[5]=Boolean.TRUE;
                //BtnBoton3.setBackgroundColor(Color.BLUE);
                //BtnBoton2.setBackgroundColor(Color.YELLOW);
                //BtnBoton6.setBackgroundColor(Color.YELLOW);
                return new int[]{3,2,6};
            case 4:
                //vecEstados[0]=Boolean.TRUE;

                //BtnBoton4.setBackgroundColor(Color.BLUE);
                //BtnBoton1.setBackgroundColor(Color.YELLOW);
                //BtnBoton5.setBackgroundColor(Color.YELLOW);
                //BtnBoton7.setBackgroundColor(Color.YELLOW);
                return new int[]{4,1,5,7};
            case 5:
                // BtnBoton2.setBackgroundColor(Color.YELLOW);
                // BtnBoton4.setBackgroundColor(Color.YELLOW);
                // BtnBoton6.setBackgroundColor(Color.YELLOW);
                // BtnBoton8.setBackgroundColor(Color.YELLOW);
                return new int[]{5,2,4,6,8};
            case 6:
                //BtnBoton3.setBackgroundColor(Color.YELLOW);
                //BtnBoton5.setBackgroundColor(Color.YELLOW);
                //BtnBoton9.setBackgroundColor(Color.YELLOW);
                return new int[]{6,3,5,9};
            case 7:
                //BtnBoton4.setBackgroundColor(Color.YELLOW);
                //BtnBoton8.setBackgroundColor(Color.YELLOW);
                return new int[]{7,4,8};
            case 8:
                //BtnBoton5.setBackgroundColor(Color.YELLOW);
                //BtnBoton7.setBackgroundColor(Color.YELLOW);
                //BtnBoton9.setBackgroundColor(Color.YELLOW);
                return new int[]{8,5,7,9};
            case 9:
                // BtnBoton6.setBackgroundColor(Color.YELLOW);
                //BtnBoton8.setBackgroundColor(Color.YELLOW);
                return new int[]{9,6,8};
            default:
                return null;
        }
    }




    private void DeclaracionVariables() {
        String viewName = "btnBoton";
        Resources res = getResources();
        int id;
        int iAux;
        for (int i = 0; i < 9; i++) {
            iAux = i+1;
            id = res.getIdentifier(viewName+i, "id", getApplicationContext().getPackageName());
            VecBtn[i] = (Button)findViewById(id);
        }
    }

    private void SetearListeners() {
        for (int i = 0; i < 9; i++) {
            VecBtn[i].setOnClickListener(btnPresionado_Click);
        }
    }

    private View.OnClickListener btnPresionado_Click = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            Button btnPresionado = (Button) v;
            String strNumero = btnPresionado.getText().toString();
            int    intNumerito = Integer.parseInt(strNumero);

            vecJugadasActuales = CasosPosibles(intNumerito);

            for (int i=0;i<vecJugadasActuales.length;i++){  //[1,2,4]
                String strPosicion= String.valueOf(vecJugadasActuales[i]);
                int intPosBoton=Integer.parseInt(strPosicion)-1;

                if(vecEstados[i]==Boolean.FALSE){
                    vecEstados[i]=Boolean.TRUE;
                    VecBtn[i].setBackgroundColor(Color.YELLOW);
                }
                else{
                    vecEstados[i]=Boolean.FALSE;
                    VecBtn[i].setBackgroundColor(Color.BLUE);
                }



            }


        }//del for

    };
    public boolean Checkear(){
        Boolean Gano;
        int ContTrue=0;
        int ContFalse=0;
        for(int i=0;i<vecJugadasActuales.length;i++){
            if(vecEstados[i]==true){
                ContTrue++;
            }
            else{
                ContFalse++;
            }
            if(ContTrue==9&&ContFalse==0)
            {

                Intent nuevaActivity = new Intent(MainActivity.this, FinActivity.class);
                Bundle datos = new Bundle();
                datos.putString(InicioActivity.NOMBRE, ReciboNombre);
                datos.putIntArray(MainActivity.);
                nuevaActivity.putExtras(datos);
                startActivity(nuevaActivity);
                Gano=true;


            }
            else if(ContFalse==9&&ContTrue==0){
                Intent nuevaActivity = new Intent(MainActivity.this, FinActivity.class);
                Bundle datos = new Bundle();
                datos.putString(InicioActivity.NOMBRE, ReciboNombre);
                datos.putIntArray(InicioActivity.???, vecJugadasActuales);
                nuevaActivity.putExtras(datos);
                startActivity(nuevaActivity);
                Gano=true;





            }




        }



        return Gano;
    }


};

