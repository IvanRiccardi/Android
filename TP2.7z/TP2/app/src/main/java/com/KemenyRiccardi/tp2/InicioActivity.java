package com.KemenyRiccardi.tp2;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class InicioActivity extends AppCompatActivity {
    EditText Nombre;
    Button btnEmpezar;
    public static  final String NOMBRE="com.KemenyRiccardi.tp2.nombre";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);


        btnEmpezar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                DeclaracionVariables();
                String StrNombre = Nombre.getText().toString();
                if (StrNombre != "") {
                    Toast MensajeOk = Toast.makeText(getApplicationContext(), "Bienvenido" + StrNombre, Toast.LENGTH_LONG);
                    MensajeOk.show();
                    Intent nuevaActivity = new Intent(InicioActivity.this, MainActivity.class);
                    Bundle datos = new Bundle();
                    datos.putString(InicioActivity.NOMBRE, StrNombre);

                    nuevaActivity.putExtras(datos);
                    startActivity(nuevaActivity);
                } else {
                    Toast Fallo = Toast.makeText(getApplicationContext(), "Por favor llene el cuadro de nombre" + StrNombre, Toast.LENGTH_LONG);
                    Fallo.show();
                }
            }


            public void DeclaracionVariables() {
                Nombre = (EditText) findViewById(R.id.EdtNombre);
                btnEmpezar = (Button) findViewById(R.id.BtnEmpezar);

                //  btnBoton= (Button) findViewById(R.id.btnBoton);
            }
        });
    }



}
